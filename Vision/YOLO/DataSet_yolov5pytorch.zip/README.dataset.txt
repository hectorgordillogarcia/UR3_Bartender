# LatasClasif > 2025-03-15 10:45pm
https://universe.roboflow.com/latas-u97yx/latasclasif

Provided by a Roboflow user
License: CC BY 4.0

